/**
 * Author Wojciech Domski <Wojciech.Domski@gmail.com>
 * www: www.Domski.pl
 *
 * work based on DORJI.COM sample code and
 * https://github.com/realspinner/SX1278_LoRa
 */

#include "SX1278.h"
#include <string.h>
#include "usart.h"
#include "gpio.h"
#include "spi.h"

// registers
#define REG_FIFO                 0x00
#define REG_OP_MODE              0x01
#define REG_FRF_MSB              0x06
#define REG_FRF_MID              0x07
#define REG_FRF_LSB              0x08
#define REG_PA_CONFIG            0x09
#define REG_LNA                  0x0c
#define REG_FIFO_ADDR_PTR        0x0d
#define REG_FIFO_TX_BASE_ADDR    0x0e
#define REG_FIFO_RX_BASE_ADDR    0x0f
#define REG_FIFO_RX_CURRENT_ADDR 0x10
#define REG_IRQ_FLAGS            0x12
#define REG_RX_NB_BYTES          0x13
#define REG_PKT_SNR_VALUE        0x19
#define REG_PKT_RSSI_VALUE       0x1a
#define REG_MODEM_CONFIG_1       0x1d
#define REG_MODEM_CONFIG_2       0x1e
#define REG_PREAMBLE_MSB         0x20
#define REG_PREAMBLE_LSB         0x21
#define REG_PAYLOAD_LENGTH       0x22
#define REG_MODEM_CONFIG_3       0x26
#define REG_FREQ_ERROR_MSB       0x28
#define REG_FREQ_ERROR_MID       0x29
#define REG_FREQ_ERROR_LSB       0x2a
#define REG_RSSI_WIDEBAND        0x2c
#define REG_DETECTION_OPTIMIZE   0x31
#define REG_DETECTION_THRESHOLD  0x37
#define REG_SYNC_WORD            0x39
#define REG_DIO_MAPPING_1        0x40
#define REG_VERSION              0x42

// modes
#define MODE_LONG_RANGE_MODE     0x80
#define MODE_SLEEP               0x00
#define MODE_STDBY               0x01
#define MODE_TX                  0x03
#define MODE_RX_CONTINUOUS       0x05
#define MODE_RX_SINGLE           0x06

// PA config
#define PA_BOOST                 0x80

// IRQ masks
#define IRQ_TX_DONE_MASK           0x08
#define IRQ_PAYLOAD_CRC_ERROR_MASK 0x20
#define IRQ_RX_DONE_MASK           0x40

#define MAX_PKT_LENGTH           255

char buffer[100];
//////////////////////////////////
// logic
//////////////////////////////////

__weak void SX1278_hw_init(SX1278_hw_t * hw) {
	SX1278_hw_SetNSS(hw, 1);
	HAL_GPIO_WritePin(hw->reset.port, hw->reset.pin, GPIO_PIN_SET);
}

__weak void SX1278_hw_SetNSS(SX1278_hw_t * hw, int value) {
	HAL_GPIO_WritePin(hw->nss.port, hw->nss.pin,
			(value == 1) ? GPIO_PIN_SET : GPIO_PIN_RESET);
	//HAL_GPIO_WritePin(NSS_GPIO_Port, NSS_Pin,
				//(value == 1) ? GPIO_PIN_SET : GPIO_PIN_RESET);

	uint8_t pinV=HAL_GPIO_ReadPin(NSS_GPIO_Port, NSS_Pin);
	//sprintf(buffer, "5.4 SX1278_hw_SetNSS hw->nss.port=%p hw->nss.pin=%i\r\n", hw->nss.port, hw->nss.pin); //sprintf will return the length of 'buffer'
	//SERIAL_print(buffer);

	//sprintf(buffer, "3.0 SX1278_hw_SetNSS pinV=%i  value=%i\r\n", pinV, value);
	//SERIAL_print(buffer);
}

__weak void SX1278_hw_Reset(SX1278_hw_t * hw) {
	SX1278_hw_SetNSS(hw, 1);
	HAL_GPIO_WritePin(hw->reset.port, hw->reset.pin, GPIO_PIN_RESET);

	SX1278_hw_DelayMs(1);

	HAL_GPIO_WritePin(hw->reset.port, hw->reset.pin, GPIO_PIN_SET);

	SX1278_hw_DelayMs(100);
}

__weak void SX1278_hw_SPICommand(SX1278_hw_t * hw, uint8_t cmd) {
	SX1278_hw_SetNSS(hw, 0);
	HAL_SPI_Transmit(hw->spi, &cmd, 1, 1000);
	while (HAL_SPI_GetState(hw->spi) != HAL_SPI_STATE_READY)
		;
}

__weak uint8_t SX1278_hw_SPIReadByte(SX1278_hw_t * hw) {
	uint8_t txByte = 0x00;
	uint8_t rxByte = 0x00;

	SX1278_hw_SetNSS(hw, 0);
	HAL_SPI_TransmitReceive(hw->spi, &txByte, &rxByte, 1, 1000);
	while (HAL_SPI_GetState(hw->spi) != HAL_SPI_STATE_READY)
		;
	return rxByte;
}

__weak void SX1278_hw_DelayMs(uint32_t msec) {
	HAL_Delay(msec);
}

__weak int SX1278_hw_GetDIO0(SX1278_hw_t * hw) {
	return (HAL_GPIO_ReadPin(hw->dio0.port, hw->dio0.pin) == GPIO_PIN_SET);
}

//////////////////////////////////
// logic
//////////////////////////////////

uint8_t SX1278_SPIRead(SX1278_t * module, uint8_t addr) {
	uint8_t tmp;
	SX1278_hw_SPICommand(module->hw, addr);
	tmp = SX1278_hw_SPIReadByte(module->hw);
	SX1278_hw_SetNSS(module->hw, 1);
	return tmp;
}

void SX1278_SPIWrite(SX1278_t * module, uint8_t addr, uint8_t cmd) {
	SX1278_hw_SetNSS(module->hw, 0);
	SX1278_hw_SPICommand(module->hw, addr | 0x80);
	SX1278_hw_SPICommand(module->hw, cmd);
	SX1278_hw_SetNSS(module->hw, 1);
}

void SX1278_SPIBurstRead(SX1278_t * module, uint8_t addr, uint8_t* rxBuf,
		uint8_t length) {
	uint8_t i;
	if (length <= 1) {
		return;
	} else {
		SX1278_hw_SetNSS(module->hw, 0);
		SX1278_hw_SPICommand(module->hw, addr);
		for (i = 0; i < length; i++) {
			*(rxBuf + i) = SX1278_hw_SPIReadByte(module->hw);
		}
		SX1278_hw_SetNSS(module->hw, 1);
	}
}

void SX1278_SPIBurstWrite(SX1278_t * module, uint8_t addr, uint8_t* txBuf,
		uint8_t length) {
	unsigned char i;
	if (length <= 1) {
		return;
	} else {
		SX1278_hw_SetNSS(module->hw, 0);
		SX1278_hw_SPICommand(module->hw, addr | 0x80);
		for (i = 0; i < length; i++) {
			SX1278_hw_SPICommand(module->hw, *(txBuf + i));
		}
		SX1278_hw_SetNSS(module->hw, 1);
	}
}

void SX1278_defaultConfig(SX1278_t * module) {
	SX1278_config(module, module->frequency, module->power, module->LoRa_Rate,
			module->LoRa_BW);

}

void SX1278_config(SX1278_t * module, uint8_t frequency, uint8_t power,
		uint8_t LoRa_Rate, uint8_t LoRa_BW) {
	SX1278_sleep(module); //Change modem mode Must in Sleep mode
	SX1278_hw_DelayMs(15);

	SX1278_entryLoRa(module);
	//SX1278_SPIWrite(module, 0x5904); //?? Change digital regulator form 1.6V to 1.47V: see errata note

	//sprintf(buffer, "PANAGIOTIS step4.2. frequency=%i\r\n", frequency);
	//SERIAL_print(buffer);

	uint8_t re = SX1278_SPIRead(module, LR_RegOpMode);
	//sprintf(buffer, "step4.3. RegOpMode=%i\r\n", re); // convert num to char
	//SERIAL_print(buffer);

	SX1278_SPIBurstWrite(module, LR_RegFrMsb,
			(uint8_t*) SX1278_Frequency[frequency], 3); //setting  frequency parameter

	//setting base parameter
	SX1278_SPIWrite(module, LR_RegPaConfig, SX1278_Power[power]); //Setting output power parameter

	SX1278_SPIWrite(module, LR_RegOcp, 0x0B);			//RegOcp,Close Ocp
	SX1278_SPIWrite(module, LR_RegLna, 0x23);		//RegLNA,High & LNA Enable
	if (SX1278_SpreadFactor[LoRa_Rate] == 6) {	//SFactor=6
		uint8_t tmp;
		SX1278_SPIWrite(module,
		LR_RegModemConfig1,
				((SX1278_LoRaBandwidth[LoRa_BW] << 4) + (SX1278_CR << 1) + 0x01)); //Implicit Enable CRC Enable(0x02) & Error Coding rate 4/5(0x01), 4/6(0x02), 4/7(0x03), 4/8(0x04)

		SX1278_SPIWrite(module,
		LR_RegModemConfig2,
				((SX1278_SpreadFactor[LoRa_Rate] << 4) + (SX1278_CRC << 2)
						+ 0x03));

		tmp = SX1278_SPIRead(module, 0x31);
		tmp &= 0xF8;
		tmp |= 0x05;
		SX1278_SPIWrite(module, 0x31, tmp);
		SX1278_SPIWrite(module, 0x37, 0x0C);
	} else {
		SX1278_SPIWrite(module,
		LR_RegModemConfig1,
				((SX1278_LoRaBandwidth[LoRa_BW] << 4) + (SX1278_CR << 1) + 0x00)); //Explicit Enable CRC Enable(0x02) & Error Coding rate 4/5(0x01), 4/6(0x02), 4/7(0x03), 4/8(0x04)

		SX1278_SPIWrite(module,
		LR_RegModemConfig2,
				((SX1278_SpreadFactor[LoRa_Rate] << 4) + (SX1278_CRC << 2)
						+ 0x03)); //SFactor &  LNA gain set by the internal AGC loop
	}

	SX1278_SPIWrite(module, LR_RegSymbTimeoutLsb, 0xFF); //RegSymbTimeoutLsb Timeout = 0x3FF(Max)
	SX1278_SPIWrite(module, LR_RegPreambleMsb, 0x00); //RegPreambleMsb
	SX1278_SPIWrite(module, LR_RegPreambleLsb, 12); //RegPreambleLsb 8+4=12byte Preamble
	SX1278_SPIWrite(module, REG_LR_DIOMAPPING2, 0x01); //RegDioMapping2 DIO5=00, DIO4=01
	module->readBytes = 0;

	uint8_t version = SX1278_readRegister(module, REG_VERSION);
	//sprintf(buffer, "5.11 version=%u\r\n", version); //sprintf will return the length of 'buffer'
	//SERIAL_print(buffer);



	SX1278_standby(module); //Entry standby mode
}

void SX1278_standby(SX1278_t * module) {
	SX1278_SPIWrite(module, LR_RegOpMode, 0x09);
	module->status = STANDBY;
}

/*void SX1278_sleep(SX1278_t * module) {
 SX1278_SPIWrite(module, LR_RegOpMode, 0x08);
 module->status = SLEEP;
 }*/

void SX1278_entryLoRa(SX1278_t * module) {
	// RegOpMode = Operating mode & LoRaTM / FSK selection
	// bits: 2-0 MODE, 3=LowFrequencyModeOn, 4=reserved, 6-5=ModulationType, 7=LongRangeMode
	// 0x88 = 0b10001000
	// 10001000 = 2-0=000->Sleep mode ,3=1->Low Frequency Mode ,6-5=00->FSK, 7=1->LoRaTM Mode
	SX1278_SPIWrite(module, LR_RegOpMode, 0x88);
}

void SX1278_clearLoRaIrq(SX1278_t * module) {
	SX1278_SPIWrite(module, LR_RegIrqFlags, 0xFF);
}

int SX1278_LoRaEntryRx(SX1278_t * module, uint8_t length, uint32_t timeout) {
	uint8_t addr;

	module->packetLength = length;

	SX1278_defaultConfig(module);		//Setting base parameter
	SX1278_SPIWrite(module, REG_LR_PADAC, 0x84);	//Normal and RX
	SX1278_SPIWrite(module, LR_RegHopPeriod, 0xFF);	//No FHSS
	SX1278_SPIWrite(module, REG_LR_DIOMAPPING1, 0x01);//DIO=00,DIO1=00,DIO2=00, DIO3=01
	SX1278_SPIWrite(module, LR_RegIrqFlagsMask, 0x3F);//Open RxDone interrupt & Timeout
	SX1278_clearLoRaIrq(module);
	SX1278_SPIWrite(module, LR_RegPayloadLength, length);//Payload Length 21byte(this register must difine when the data long of one byte in SF is 6)
	addr = SX1278_SPIRead(module, LR_RegFifoRxBaseAddr); //Read RxBaseAddr
	SX1278_SPIWrite(module, LR_RegFifoAddrPtr, addr); //RxBaseAddr->FiFoAddrPtr
	SX1278_SPIWrite(module, LR_RegOpMode, 0x8d);	//Mode//Low Frequency Mode
	//SX1278_SPIWrite(module, LR_RegOpMode,0x05);	//Continuous Rx Mode //High Frequency Mode
	module->readBytes = 0;

	while (1) {
		if ((SX1278_SPIRead(module, LR_RegModemStat) & 0x04) == 0x04) {	//Rx-on going RegModemStat
			module->status = RX;
			return 1;
		}
		if (--timeout == 0) {
			SX1278_hw_Reset(module->hw);
			SX1278_defaultConfig(module);
			return 0;
		}
		SX1278_hw_DelayMs(1);
	}
}

uint8_t SX1278_LoRaRxPacket(SX1278_t * module) {
	unsigned char addr;
	unsigned char packet_size;

	if (SX1278_hw_GetDIO0(module->hw)) {
		memset(module->rxBuffer, 0x00, SX1278_MAX_PACKET);

		addr = SX1278_SPIRead(module, LR_RegFifoRxCurrentaddr); //last packet addr
		SX1278_SPIWrite(module, LR_RegFifoAddrPtr, addr); //RxBaseAddr -> FiFoAddrPtr

		if (module->LoRa_Rate == SX1278_LORA_SF_6) { //When SpreadFactor is six,will used Implicit Header mode(Excluding internal packet length)
			packet_size = module->packetLength;
		} else {
			packet_size = SX1278_SPIRead(module, LR_RegRxNbBytes); //Number for received bytes
		}

		SX1278_SPIBurstRead(module, 0x00, module->rxBuffer, packet_size);
		module->readBytes = packet_size;
		SX1278_clearLoRaIrq(module);
	}
	return module->readBytes;
}

int SX1278_LoRaEntryTx(SX1278_t * module, uint8_t length, uint32_t timeout) {
	uint8_t addr;
	uint8_t temp;

	module->packetLength = length;
	//char buffer[100];
	//sprintf(buffer, "step4. module->packetLength=%i\r\n", module->packetLength); // convert num to char
	//HAL_UART_print_char(buffer);

	SX1278_defaultConfig(module); //setting base parameter
	SX1278_SPIWrite(module, REG_LR_PADAC, 0x87);	//Tx for 20dBm
	SX1278_SPIWrite(module, LR_RegHopPeriod, 0x00); //RegHopPeriod NO FHSS
	SX1278_SPIWrite(module, REG_LR_DIOMAPPING1, 0x41); //DIO0=01, DIO1=00,DIO2=00, DIO3=01
	SX1278_clearLoRaIrq(module);
	SX1278_SPIWrite(module, LR_RegIrqFlagsMask, 0xF7); //Open TxDone interrupt
	SX1278_SPIWrite(module, LR_RegPayloadLength, length); //RegPayloadLength 21byte
	addr = SX1278_SPIRead(module, LR_RegFifoTxBaseAddr); //RegFiFoTxBaseAddr
	SX1278_SPIWrite(module, LR_RegFifoAddrPtr, addr); //RegFifoAddrPtr

	while (1) {
		temp = SX1278_SPIRead(module, LR_RegPayloadLength);
		if (temp == length) {
			module->status = TX;
			return 1;
		}

		if (--timeout == 0) {
			SX1278_hw_Reset(module->hw);
			SX1278_defaultConfig(module);
			return 0;
		}
	}
}

int SX1278_LoRaTxPacket(SX1278_t * module, uint8_t* txBuffer, uint8_t length,
		uint32_t timeout) {
	SX1278_SPIBurstWrite(module, 0x00, txBuffer, length);
	SX1278_SPIWrite(module, LR_RegOpMode, 0x8b);	//Tx Mode

	//print out variable txBuffer
	//sprintf(buffer, "txBuffer=\%s \r\n", txBuffer);
	//SERIAL_print(buffer);

	while (1) {
		if (SX1278_hw_GetDIO0(module->hw)) { //if(Get_NIRQ()) //Packet send over
			SX1278_SPIRead(module, LR_RegIrqFlags);
			SX1278_clearLoRaIrq(module); //Clear irq
			SX1278_standby(module); //Entry Standby mode
			return 1;
		}

		if (--timeout == 0) {
			SX1278_hw_Reset(module->hw);
			SX1278_defaultConfig(module);
			return 0;
		}
		SX1278_hw_DelayMs(1);
	}
}
/*
 void SX1278_begin(SX1278_t * module, uint8_t frequency, uint8_t power,
 uint8_t LoRa_Rate, uint8_t LoRa_BW, uint8_t packetLength) {
 SX1278_hw_init(module->hw);
 module->frequency = frequency;
 module->power = power;
 module->LoRa_Rate = LoRa_Rate;
 module->LoRa_BW = LoRa_BW;
 module->packetLength = packetLength;
 SX1278_defaultConfig(module);
 }
 */
int SX1278_transmit(SX1278_t * module, uint8_t* txBuf, uint8_t length,
		uint32_t timeout) {
	if (SX1278_LoRaEntryTx(module, length, timeout)) {
		return SX1278_LoRaTxPacket(module, txBuf, length, timeout);
	}
	return 0;
}

int SX1278_receive(SX1278_t * module, uint8_t length, uint32_t timeout) {
	return SX1278_LoRaEntryRx(module, length, timeout);
}
/*
 uint8_t SX1278_available(SX1278_t * module) {
 return SX1278_LoRaRxPacket(module);
 }
 */
/*
 uint8_t SX1278_read(SX1278_t * module, uint8_t* rxBuf, uint8_t length) {
 if (length != module->readBytes)
 length = module->readBytes;
 memcpy(rxBuf, module->rxBuffer, length);
 rxBuf[length] = '\0';
 module->readBytes = 0;
 return length;
 }
 */
uint8_t SX1278_RSSI_LoRa(SX1278_t * module) {
	uint32_t temp = 10;
	temp = SX1278_SPIRead(module, LR_RegRssiValue); //Read RegRssiValue, Rssi value
	temp = temp + 127 - 137; //127:Max RSSI, 137:RSSI offset
	return (uint8_t) temp;
}

uint8_t SX1278_RSSI(SX1278_t * module) {
	uint8_t temp = 0xff;
	temp = SX1278_SPIRead(module, 0x11);
	temp = 127 - (temp >> 1);	//127:Max RSSI
	return temp;
}
/*
 void SX1278_setSyncWord(SX1278_t * module, int sw) {
 //writeRegister(RegSyncWord, sw);
 SX1278_SPIWrite(module, RegSyncWord, sw);
 }
 */
// SX1278_sleep existing
void SX1278_sleep(SX1278_t * module) {
	SX1278_writeRegister(module, REG_OP_MODE,
	MODE_LONG_RANGE_MODE | MODE_SLEEP);
	module->status = SLEEP;
}

/*
 uint8_t SX1278_readRegister(uint8_t address) {
 return singleTransfer(address & 0x7f, 0x00);
 }
 */

// void LoRaClass::writeRegister(uint8_t address, uint8_t value)
void SX1278_writeRegister(SX1278_t * module, uint8_t addr, uint8_t cmd) {
	SX1278_singleTransfer(module, addr | 0x80, cmd);
}

uint8_t SX1278_singleTransfer(SX1278_t * module, uint8_t addr, uint8_t cmd) {
	uint8_t response = 0;

	SX1278_hw_SetNSS(module->hw, 0);
	SX1278_hw_SPICommand(module->hw, addr);
	SX1278_hw_SPICommand(module->hw, cmd);
	SX1278_hw_SetNSS(module->hw, 1);

	//sprintf(buffer, "5.3 SX1278_readRegister addr=%u\r\n", addr); //sprintf will return the length of 'buffer'
	//SERIAL_print(buffer);

	return response;
}

/*
uint8_t LoRaClass::singleTransfer(uint8_t address, uint8_t value)
{
  uint8_t response;

  digitalWrite(_ss, LOW);

  _spi->beginTransaction(_spiSettings);
  _spi->transfer(address);
  response = _spi->transfer(value);
  _spi->endTransaction();

  digitalWrite(_ss, HIGH);

  return response;
}*/

void SX1278_setFrequency(SX1278_t * module, long frequency) {
	frequency = 433E6;
	_frequency = frequency;

	//sprintf(buffer, "5.5 SX1278_setFrequency frequency=%ld\r\n", frequency); //sprintf will return the length of 'buffer'
	//SERIAL_print(buffer);

	uint64_t frf = ((uint64_t) frequency << 19) / 32000000;

	SX1278_writeRegister(module, REG_FRF_MSB, (uint8_t) (frf >> 16));
	SX1278_writeRegister(module, REG_FRF_MID, (uint8_t) (frf >> 8));
	SX1278_writeRegister(module, REG_FRF_LSB, (uint8_t) (frf >> 0));

	uint8_t r1 = SX1278_readRegister(module, REG_FRF_MSB);
	uint8_t r2 = SX1278_readRegister(module, REG_FRF_MID);
	uint8_t r3 = SX1278_readRegister(module, REG_FRF_LSB);
	//sprintf(buffer, "5.6 SX1278_setFrequency REG_FRF_MSB=%u REG_FRF_MID=%u REG_FRF_LSB=%u\r\n", r1, r2, r3); //sprintf will return the length of 'buffer'
	//SERIAL_print(buffer);
}

void SX1278_setTxPower(SX1278_t * module, int level, int outputPin) {
	if (PA_OUTPUT_RFO_PIN == outputPin) {
		// RFO
		if (level < 0) {
			level = 0;
		} else if (level > 14) {
			level = 14;
		}

		SX1278_writeRegister(module, REG_PA_CONFIG, 0x70 | level);
	} else {
		// PA BOOST
		if (level < 2) {
			level = 2;
		} else if (level > 17) {
			level = 17;
		}

		SX1278_writeRegister(module, REG_PA_CONFIG, PA_BOOST | (level - 2));
	}
}

void SX1278_idle(SX1278_t * module) {
	SX1278_writeRegister(module, REG_OP_MODE,
	MODE_LONG_RANGE_MODE | MODE_STDBY);
}

void SX1278_end(SX1278_t * module) {
	// put in sleep mode
	SX1278_sleep(module);

	// stop SPI
	//_spi->end();
}

void SX1278_explicitHeaderMode(SX1278_t * module) {
	_implicitHeaderMode = 0;

	SX1278_writeRegister(module, REG_MODEM_CONFIG_1,
			SX1278_readRegister(module, REG_MODEM_CONFIG_1) & 0xfe);
}

void SX1278_implicitHeaderMode(SX1278_t * module) {
	_implicitHeaderMode = 1;

	SX1278_writeRegister(module, REG_MODEM_CONFIG_1,
			SX1278_readRegister(module, REG_MODEM_CONFIG_1) | 0x01);
}

int SX1278_beginPacket(SX1278_t * module, int implicitHeader) {
	// put in standby mode
	SX1278_idle(module);

	if (implicitHeader) {
		SX1278_implicitHeaderMode(module);
	} else {
		SX1278_explicitHeaderMode(module);
	}

	// reset FIFO address and paload length
	SX1278_writeRegister(module, REG_FIFO_ADDR_PTR, 0);
	SX1278_writeRegister(module, REG_PAYLOAD_LENGTH, 0);

	return 1;
}

int SX1278_endPacket(SX1278_t * module) {
	// put in TX mode
	SX1278_writeRegister(module, REG_OP_MODE, MODE_LONG_RANGE_MODE | MODE_TX);

	// wait for TX done
	while ((SX1278_readRegister(module, (REG_IRQ_FLAGS) & IRQ_TX_DONE_MASK) == 0)) {
		//yield(); ??????????????????????????
	}

	// clear IRQ's
	SX1278_writeRegister(module, REG_IRQ_FLAGS, IRQ_TX_DONE_MASK);

	return 1;
}

uint8_t SX1278_readRegister(SX1278_t * module, uint8_t address) {
	//sprintf(buffer, "5.3 SX1278_readRegister address=%u\r\n", address); //sprintf will return the length of 'buffer'
	//SERIAL_print(buffer);
	return SX1278_singleTransfer(module, address & 0x7f, 0x00);
}

int SX1278_parsePacket(SX1278_t * module, int size) {
	int packetLength = 0;
	int irqFlags = SX1278_readRegister(module, REG_IRQ_FLAGS);

	if (size > 0) {
		SX1278_implicitHeaderMode(module);

		SX1278_writeRegister(module, REG_PAYLOAD_LENGTH, size & 0xff);
	} else {
		SX1278_explicitHeaderMode(module);
	}

	// clear IRQ's
	SX1278_writeRegister(module, REG_IRQ_FLAGS, irqFlags);

	if ((irqFlags & IRQ_RX_DONE_MASK)
			&& (irqFlags & IRQ_PAYLOAD_CRC_ERROR_MASK) == 0) {
		// received a packet
		_packetIndex = 0;

		// read packet length
		if (_implicitHeaderMode) {
			packetLength = SX1278_readRegister(module, REG_PAYLOAD_LENGTH);
		} else {
			packetLength = SX1278_readRegister(module, REG_RX_NB_BYTES);
		}

		// set FIFO address to current RX address
		SX1278_writeRegister(module, REG_FIFO_ADDR_PTR,
				SX1278_readRegister(module, REG_FIFO_RX_CURRENT_ADDR));

		// put in standby mode
		SX1278_idle(module);
	} else if (SX1278_readRegister(module,
			(REG_OP_MODE) != (MODE_LONG_RANGE_MODE | MODE_RX_SINGLE))) {
		// not currently in RX mode

		// reset FIFO address
		SX1278_writeRegister(module, REG_FIFO_ADDR_PTR, 0);

		// put in single RX mode
		SX1278_writeRegister(module, REG_OP_MODE,
		MODE_LONG_RANGE_MODE | MODE_RX_SINGLE);
	}

	return packetLength;
}

int SX1278_packetRssi(SX1278_t * module) {
	return (SX1278_readRegister(module, REG_PKT_RSSI_VALUE)
			- (_frequency < 868E6 ? 164 : 157));

}

float SX1278_packetSnr(SX1278_t * module) {
	return ((int8_t) SX1278_readRegister(module, REG_PKT_SNR_VALUE)) * 0.25;

}

//???????????????????????????????????????????
long SX1278_packetFrequencyError(SX1278_t * module) {

	int32_t freqError = 0;
	freqError = (int32_t) (SX1278_readRegister(module, REG_FREQ_ERROR_MSB)
			& 0b00000111);

	freqError <<= 8L;
	freqError += (int32_t) (SX1278_readRegister(module, REG_FREQ_ERROR_MID));
	freqError <<= 8L;
	freqError += (int32_t) (SX1278_readRegister(module, REG_FREQ_ERROR_LSB));

	if (SX1278_readRegister(module, REG_FREQ_ERROR_MSB) & 0b0001000) { // Sign bit is on
		freqError -= 524288; // B1000'0000'0000'0000'0000
	}

	const float fXtal = 32E6; // FXOSC: crystal oscillator (XTAL) frequency (2.5. Chip Specification, p. 14)
	const float fError = (((float) (freqError) * (1L << 24)) / fXtal)
			* (SX1278_getSignalBandwidth(module) / 500000.0f); // p. 37

	return (long) (fError);

	return 1;
}

size_t SX1278_write(SX1278_t * module, uint8_t byte) {
	return SX1278_write_b(module, &byte, sizeof(byte));
}

size_t SX1278_write_b(SX1278_t * module, const uint8_t *buffer, size_t size) {
	int currentLength = SX1278_readRegister(module, REG_PAYLOAD_LENGTH);

	// check size
	if ((currentLength + size) > MAX_PKT_LENGTH) {
		size = MAX_PKT_LENGTH - currentLength;
	}

	// write data
	for (size_t i = 0; i < size; i++) {
		SX1278_writeRegister(module, REG_FIFO, buffer[i]);
	}

	// update length
	SX1278_writeRegister(module, REG_PAYLOAD_LENGTH, currentLength + size);

	return size;
}

// ??????????????????????????????????????????????????
int SX1278_available(SX1278_t * module) {
	return (SX1278_readRegister(module, REG_RX_NB_BYTES) - _packetIndex);
}

int SX1278_read(SX1278_t * module) {
	if (!SX1278_available(module)) {
		return -1;
	}

	_packetIndex++;
	module->readBytes = 0;
	return SX1278_readRegister(module, REG_FIFO);
}

int SX1278_peek(SX1278_t * module) {
	if (!SX1278_available(module)) {
		return -1;
	}

	// store current FIFO address
	int currentAddress = SX1278_readRegister(module, REG_FIFO_ADDR_PTR);

	// read
	uint8_t b = SX1278_readRegister(module, REG_FIFO);

	// restore FIFO address
	SX1278_writeRegister(module, REG_FIFO_ADDR_PTR, currentAddress);

	return b;
}

void SX1278_flush() {
}
/*
 #ifndef ARDUINO_SAMD_MKRWAN1300
 void LoRaClass::onReceive(void(*callback)(int))
 {
 _onReceive = callback;

 if (callback) {
 pinMode(_dio0, INPUT);

 writeRegister(REG_DIO_MAPPING_1, 0x00);
 #ifdef SPI_HAS_NOTUSINGINTERRUPT
 SPI.usingInterrupt(digitalPinToInterrupt(_dio0));
 #endif
 attachInterrupt(digitalPinToInterrupt(_dio0), LoRaClass::onDio0Rise, RISING);
 } else {
 detachInterrupt(digitalPinToInterrupt(_dio0));
 #ifdef SPI_HAS_NOTUSINGINTERRUPT
 SPI.notUsingInterrupt(digitalPinToInterrupt(_dio0));
 #endif
 }
 }




 void SX1278_receive(int size)
 {
 if (size > 0) {
 SX1278_implicitHeaderMode();

 SX1278_writeRegister(REG_PAYLOAD_LENGTH, size & 0xff);
 } else {
 SX1278_explicitHeaderMode();
 }

 SX1278_writeRegister(REG_OP_MODE, MODE_LONG_RANGE_MODE | MODE_RX_CONTINUOUS);
 }
 #endif
 */

int SX1278_getSpreadingFactor(SX1278_t * module) {
	return SX1278_readRegister(module, REG_MODEM_CONFIG_2) >> 4;
}

void SX1278_setSpreadingFactor(SX1278_t * module, int sf) {
	if (sf < 6) {
		sf = 6;
	} else if (sf > 12) {
		sf = 12;
	}

	if (sf == 6) {
		SX1278_writeRegister(module, REG_DETECTION_OPTIMIZE, 0xc5);
		SX1278_writeRegister(module, REG_DETECTION_THRESHOLD, 0x0c);
	} else {
		SX1278_writeRegister(module, REG_DETECTION_OPTIMIZE, 0xc3);
		SX1278_writeRegister(module, REG_DETECTION_THRESHOLD, 0x0a);
	}

	SX1278_writeRegister(module, REG_MODEM_CONFIG_2,
			(SX1278_readRegister(module, REG_MODEM_CONFIG_2) & 0x0f)
					| ((sf << 4) & 0xf0));
	setLdoFlag(module);
}

long SX1278_getSignalBandwidth(SX1278_t * module) {
	byte bw = (SX1278_readRegister(module, (REG_MODEM_CONFIG_1) >> 4));
	switch (bw) {
	case 0:
		return 7.8E3;
	case 1:
		return 10.4E3;
	case 2:
		return 15.6E3;
	case 3:
		return 20.8E3;
	case 4:
		return 31.25E3;
	case 5:
		return 41.7E3;
	case 6:
		return 62.5E3;
	case 7:
		return 125E3;
	case 8:
		return 250E3;
	case 9:
		return 500E3;
	}
	return 0;
}

void SX1278_setSignalBandwidth(SX1278_t * module, long sbw) {
	int bw;

	if (sbw <= 7.8E3) {
		bw = 0;
	} else if (sbw <= 10.4E3) {
		bw = 1;
	} else if (sbw <= 15.6E3) {
		bw = 2;
	} else if (sbw <= 20.8E3) {
		bw = 3;
	} else if (sbw <= 31.25E3) {
		bw = 4;
	} else if (sbw <= 41.7E3) {
		bw = 5;
	} else if (sbw <= 62.5E3) {
		bw = 6;
	} else if (sbw <= 125E3) {
		bw = 7;
	} else if (sbw <= 250E3) {
		bw = 8;
	} else /*if (sbw <= 250E3)*/{
		bw = 9;
	}

	SX1278_writeRegister(module, REG_MODEM_CONFIG_1,
			(SX1278_readRegister(module, (REG_MODEM_CONFIG_1) & 0x0f))
					| (bw << 4));
	setLdoFlag(module);
}

void setLdoFlag(SX1278_t * module) {
	// Section 4.1.1.5
	long symbolDuration = 1000
			/ (SX1278_getSignalBandwidth(module)
					/ (1L << SX1278_getSpreadingFactor(module)));

	// Section 4.1.1.6
	bool ldoOn = symbolDuration > 16;

	uint8_t config3 = SX1278_readRegister(module, REG_MODEM_CONFIG_3);
	bitWrite(config3, 3, ldoOn);
	SX1278_writeRegister(module, REG_MODEM_CONFIG_3, config3);
}

void SX1278_setCodingRate4(SX1278_t * module, int denominator) {
	if (denominator < 5) {
		denominator = 5;
	} else if (denominator > 8) {
		denominator = 8;
	}

	int cr = denominator - 4;

	SX1278_writeRegister(module, REG_MODEM_CONFIG_1,
			(SX1278_readRegister(module, REG_MODEM_CONFIG_1) & 0xf1)
					| (cr << 1));
}

void SX1278_setPreambleLength(SX1278_t * module, long length) {
	SX1278_writeRegister(module, REG_PREAMBLE_MSB, (uint8_t) (length >> 8));
	SX1278_writeRegister(module, REG_PREAMBLE_LSB, (uint8_t) (length >> 0));
}

void SX1278_setSyncWord(SX1278_t * module, int sw) {
	SX1278_writeRegister(module, REG_SYNC_WORD, sw);
}

void SX1278_enableCrc(SX1278_t * module) {
	SX1278_writeRegister(module, REG_MODEM_CONFIG_2,
			SX1278_readRegister(module, REG_MODEM_CONFIG_2) | 0x04);
}

void SX1278_disableCrc(SX1278_t * module) {
	SX1278_writeRegister(module, REG_MODEM_CONFIG_2,
			SX1278_readRegister(module, REG_MODEM_CONFIG_2) & 0xfb);
}

byte SX1278_random(SX1278_t * module) {
	return SX1278_readRegister(module, REG_RSSI_WIDEBAND);
}

void SX1278_setPins(int ss, int reset, int dio0) {
	//NSS_Pin, NSS_GPIO_Port, RESET_Pin, RESET_GPIO_Port
	_ss = NSS_Pin;
	//_ss_port = NSS_GPIO_Port;

	_reset = RESET_Pin;
	//_reset_port = RESET_GPIO_Port;
	_dio0 = dio0;
}
/*
 void SX1278_setSPI(SPIClass& spi)
 {
 _spi = &spi;
 }

 void SX1278_setSPIFrequency(uint32_t frequency)
 {
 _spiSettings = SPISettings(frequency, MSBFIRST, SPI_MODE0);
 }
 */

/*
 void SX1278_dumpRegisters(SX1278_t * module, Stream& out)
 {
 for (int i = 0; i < 128; i++) {
 out.print("0x");
 out.print(i, HEX);
 out.print(": 0x");
 out.println(SX1278_readRegister(module, i), HEX);
 }
 }
 */

void SX1278_handleDio0Rise(SX1278_t * module) {
	int irqFlags = SX1278_readRegister(module, REG_IRQ_FLAGS);

	// clear IRQ's
	SX1278_writeRegister(module, REG_IRQ_FLAGS, irqFlags);

	if ((irqFlags & IRQ_PAYLOAD_CRC_ERROR_MASK) == 0) {
		// received a packet
		_packetIndex = 0;

		// read packet length
		int packetLength =
				_implicitHeaderMode ?
						SX1278_readRegister(module, REG_PAYLOAD_LENGTH) :
						SX1278_readRegister(module, REG_RX_NB_BYTES);

		// set FIFO address to current RX address
		SX1278_writeRegister(module, REG_FIFO_ADDR_PTR,
				SX1278_readRegister(module, REG_FIFO_RX_CURRENT_ADDR));

		if (_onReceive) {
			_onReceive(packetLength);
		}

		// reset FIFO address
		SX1278_writeRegister(module, REG_FIFO_ADDR_PTR, 0);
	}
}

void SX1278_onDio0Rise(SX1278_t * module) {
	SX1278_handleDio0Rise(module);
}

/*int SX1278_begin(SX1278_t * module, long frequency) {

	// setup pins
	// pinMode(_ss, OUTPUT);
	// set SS high
	// digitalWrite(_ss, HIGH);

	_frequency = 0;
	_packetIndex = 0;
	_implicitHeaderMode = 0;

	HAL_GPIO_WritePin(NSS_GPIO_Port, NSS_Pin, GPIO_PIN_SET);

	sprintf(buffer, "5.1 _reset=%i\r\n", _reset);
	SERIAL_print(buffer);

	if (_reset != -1) {
		//pinMode(_reset, OUTPUT);

		// perform reset
		HAL_GPIO_WritePin(RESET_GPIO_Port, RESET_Pin, GPIO_PIN_RESET);
		HAL_Delay(100);
		HAL_GPIO_WritePin(RESET_GPIO_Port, RESET_Pin, GPIO_PIN_SET);
		HAL_Delay(100);
	}

	// start SPI
	//_spi->begin();


	// check version
	uint8_t version = SX1278_readRegister(module, REG_VERSION);
	if (version != 0x12) {
		sprintf(buffer, "5.1 version=%u\r\n", version); //sprintf will return the length of 'buffer'
		SERIAL_print(buffer);
		return 0;
	}

	// put in sleep mode
	SX1278_sleep(module);

	// set frequency
	SX1278_setFrequency(module, frequency);

	// set base addresses
	SX1278_writeRegister(module, REG_FIFO_TX_BASE_ADDR, 0);
	SX1278_writeRegister(module, REG_FIFO_RX_BASE_ADDR, 0);

	// set LNA boost
	SX1278_writeRegister(module, REG_LNA,
			SX1278_readRegister(module, REG_LNA) | 0x03);

	// set auto AGC
	SX1278_writeRegister(module, REG_MODEM_CONFIG_3, 0x04);

	// set output power to 17 dBm
	SX1278_setTxPower(module, 17, 1); ///???? I must clear out outputpin

	// put in standby mode
	SX1278_idle(module);

	return 1;
}
*/


void SX1278_begin(SX1278_t * module, uint8_t frequency, uint8_t power,
		uint8_t LoRa_Rate, uint8_t LoRa_BW, uint8_t packetLength) {
	SX1278_hw_init(module->hw);
	module->frequency = frequency;
	module->power = power;
	module->LoRa_Rate = LoRa_Rate;
	module->LoRa_BW = LoRa_BW;
	module->packetLength = packetLength;
	SX1278_defaultConfig(module);
}
